using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class player : MonoBehaviour

{
    public TextMeshProUGUI scoreText;

    public TextMeshProUGUI collectibleText;

    public TextMeshProUGUI helpText;

    public GameObject keyIndicator;

    public GameObject keycardIndicator;

    public GameObject congrats;

    public GameObject description;

    public int currentScore = 0;

    public int collectibleScore = 0;

    public int totalCollectibles = 9;

    bool isKey = false;




    // store the current door

    Door currentDoor;
    Collectible currentCollectible;
    Keycard currentKeycard;
    PinkKey currentPinkKey;
    PuzzleButton currentButton;


    public Door linkedDoor;

    public void IncreaseScore(int scoreToAdd)
    {
        currentScore += scoreToAdd;
        collectibleScore++;
        scoreText.text = "Score: " + currentScore.ToString();
        collectibleText.text = "Collectibles: " + collectibleScore + " / 9";
    }

    public void UpdateDoor(Door newDoor)
    {
        currentDoor = newDoor;
        if (currentDoor != null)
        {
            if (currentDoor.locked == false)
            {
                helpText.text = "Press E to open door";
            }
            else
            {
                if (currentDoor.name == "Door Limit" && currentDoor.locked == true)
                {
                    helpText.text = "The door is locked. Get at least 25 score to unlock.";
                }
                else if (currentDoor.name == "Door Special" && currentDoor.locked == true)
                {
                    helpText.text = "The door is locked. Find something to unlock it.";
                }
                else if (currentDoor.name == "Door Box" && currentDoor.locked == true)
                {
                    helpText.text = "The door is locked. Look around...";
                }
                else if (currentDoor.name == "Lock" && currentDoor.locked == true)
                {
                    helpText.text = "The cage is locked. Find something to unlock it.";
                }
            }                      
        }
        else
        {
            helpText.text = " ";
        }
    }

    public void UpdateCollectible(Collectible newCollectible) 
    {
        currentCollectible = newCollectible;
        if (currentCollectible != null)
        {
            helpText.text = "Press E to collect";
        }
        else
        {
            helpText.text = " ";
        }
    }

    public void UpdateKeycard(Keycard newKeycard)
    {
        currentKeycard = newKeycard;
        if (currentKeycard != null)
        {
            helpText.text = "Press E to collect";
        }
        else
        {
            helpText.text = " ";
        }
    }

    public void UpdatePinkKey(PinkKey newPinkKey)
    {
        currentPinkKey = newPinkKey;
        if (currentPinkKey != null)
        {
            isKey = true;
            helpText.text = "Press E to collect";
        }
        else
        {
            isKey = false;
            helpText.text = " ";
        }
    }

    public void UpdateButton(PuzzleButton newButton)
    {
        currentButton = newButton;
        if (currentButton != null)
        {
            helpText.text = "Press E to push button";
        }
        else
        {
            helpText.text = " ";
        }
    }

    void OnInteract()
    {
        if (currentCollectible != null)
        {
            IncreaseScore(currentCollectible.myScore);
            currentCollectible.Collected();
            helpText.text = " ";
        }
        if (currentKeycard != null)
        {
            currentKeycard.linkedDoor.SetLock(false);
            currentKeycard.Collected();
            helpText.text = " ";
            keycardIndicator.SetActive(true);

        }
        if (currentPinkKey != null)
        {
            currentPinkKey.Collected();
            helpText.text = " ";
            keyIndicator.SetActive(true);
        }
        if (currentDoor != null)
        {
            if (currentDoor.name == "Lock")
            {
                if (isKey == true)
                {
                    currentDoor.doorbox.SetActive(false);
                    helpText.text = " ";
                }
            }
            else
            {
                currentDoor.OpenDoor();
                currentDoor = null;
                helpText.text = " ";
            }
        }
        if (currentButton != null)
        {
            GameObject.Find("Glass Wall 2").GetComponent<GlassWall2>().ButtonCheck(currentButton);

        }

    }

    // Start is called before the first frame update
    void Start()
    {
        scoreText.text = "Score: 0";
        collectibleText.text = "Collectibles: 0 / 9";

    }

    // Update is called once per frame
    void Update()
    {
        if (collectibleScore == totalCollectibles)
        {
            congrats.SetActive(true);
            description.SetActive(true);
        }
    }
}
