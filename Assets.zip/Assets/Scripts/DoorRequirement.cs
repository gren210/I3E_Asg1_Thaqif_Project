using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorRequirement : MonoBehaviour
{
    public int scoreRequirement = 3;

    public Door linkedDoor;

    int currentScore;


    //private void OnCollisionEnter(Collision collision)
    //{
        //if (collision.gameObject.tag == "Player")
        //{
            //collision.gameObject.GetComponent<player>().UpdateKeycard(this);
        //}
    //}
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        currentScore = GameObject.Find("PlayerCapsule").GetComponent<player>().currentScore;
        if (currentScore >= scoreRequirement)
        {
            linkedDoor.SetLock(false);
        }

    }
}
