using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColouredPlates : MonoBehaviour
{
    public bool triggered = false;
    public Material colour;
    private GameObject wall;


    // Start is called before the first frame update
    void Start()
    {
        wall = GameObject.Find("Glass Wall");
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (colour == collider.gameObject.GetComponent<MeshRenderer>().sharedMaterial)
        {
            triggered = true;
            Debug.Log(triggered);
        }
    }

    private void OnTriggerExit(Collider collider)
    {
        if (colour == collider.gameObject.GetComponent<MeshRenderer>().sharedMaterial)
        {
            wall.SetActive(true);
            triggered = false;
            Debug.Log(triggered);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
