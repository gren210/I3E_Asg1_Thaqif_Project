using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlassWall : MonoBehaviour
{
    private GameObject redPlate;
    private GameObject greenPlate;
    private GameObject bluePlate;
    private bool redTrigger = false;
    private bool greenTrigger = false;
    private bool blueTrigger = false;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        redPlate = GameObject.Find("Red Plate");
        redTrigger = redPlate.gameObject.GetComponent<ColouredPlates>().triggered;

        greenPlate = GameObject.Find("Green Plate");
        greenTrigger = greenPlate.gameObject.GetComponent<ColouredPlates>().triggered;

        bluePlate = GameObject.Find("Blue Plate");
        blueTrigger = bluePlate.gameObject.GetComponent<ColouredPlates>().triggered;

        if (redTrigger && greenTrigger && blueTrigger)
        {
            gameObject.SetActive(false);
        }
    }
}
