using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LockIndicator : MonoBehaviour
{ 
    public Door linkedDoor;

    public Material unlockedLight;

    public Material lockedLight;


    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (linkedDoor.locked == false)
        {
            gameObject.GetComponent<MeshRenderer>().material = unlockedLight;
        }
        else if (linkedDoor.locked == true)
        {
            gameObject.GetComponent<MeshRenderer>().material = lockedLight;
        }
    }
}
