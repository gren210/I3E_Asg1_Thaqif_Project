using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlassWall2 : MonoBehaviour
{
    public Material correct;

    public Material wrong;

    GameObject currentLight;
    GameObject first;
    GameObject second;
    GameObject third;
    GameObject fourth;

    bool isnotCheck = true;

    Material[] materialOrder;
    public GameObject[] objectOrder;
    Material[] originalMat = {null,null,null,null};

    string[] order = { "BluePlate", "OrangeMat", "CyanButton", "PurpleButton" };
    Material[] buttonOrder = {null,null,null ,null};
    int count = 0;

    private void OriginalLight(Material[] originalMat)
    {
        Material[] materialOrder = new Material[] { first.GetComponent<MeshRenderer>().material, second.GetComponent<MeshRenderer>().material, third.GetComponent<MeshRenderer>().material, fourth.GetComponent<MeshRenderer>().material };
        GameObject[] objectOrder = new GameObject[] {first, second, third, fourth};
        for (int i = 0; i < 4; i++)
        {
            objectOrder[i].GetComponent<MeshRenderer>().material = originalMat[i];
            //if (buttonOrder[i] != null)
            //{
            //objectOrder[i].GetComponent<MeshRenderer>().material = buttonOrder[i];
            //}
            //else
            //{
            //Debug.Log(buttonOrder[i]);
            //objectOrder[i].GetComponent<MeshRenderer>().material = buttonOrder[i];
            //}
        }
    }

    private IEnumerator DelayedLight(Material[] originalMat)
    {
        yield return new WaitForSeconds(1.0f);
        OriginalLight(originalMat);
    }

    private void WrongLight()
    {
        GameObject[] objectOrder = new GameObject[] {first, second, third, fourth};
        for (int i = 0; i < 4; i++)
        {
            //materialOrder[i] = objectOrder[i].GetComponent<MeshRenderer>().material;
            objectOrder[i].GetComponent<MeshRenderer>().material = wrong;
        }
    }


    public void ButtonCheck(PuzzleButton buttonMat)
    {
        GameObject[] objectOrder = new GameObject[] {first, second, third, fourth};
        //if (count == 0)
        //{
        //Material[] originalMat = new Material[] { first.GetComponent<MeshRenderer>().material, second.GetComponent<MeshRenderer>().material, third.GetComponent<MeshRenderer>().material, fourth.GetComponent<MeshRenderer>().material };
        //}
        if (count == 0 && isnotCheck)
        {
            for (int i = 0; i < 4; i++)
            {
                originalMat[i] = objectOrder[i].GetComponent<MeshRenderer>().material;
            }
            isnotCheck = false;
        }

        if (buttonMat.colour.name == order[count])
        {
            buttonOrder[count] = buttonMat.colour;
            currentLight = objectOrder[count];
            currentLight.GetComponent<MeshRenderer>().material = correct;
            count++;
        }
        else
        {
            Material[] buttonOrder = {null,null,null,null};
            count = 0;
            WrongLight();
            StartCoroutine(DelayedLight(originalMat));
        }
    }


    // Start is called before the first frame update
    void Start()
    {
        first = GameObject.Find("Ocean Blue");
        second = GameObject.Find("Orange");
        third = GameObject.Find("Cyan");
        fourth = GameObject.Find("Purple");

    }


    // Update is called once per frame
    void Update()
    {
        if ((buttonOrder[0] && buttonOrder[1] && buttonOrder[2] && buttonOrder[3]) == correct)
        {
            gameObject.SetActive(false);
        }
    }
}
