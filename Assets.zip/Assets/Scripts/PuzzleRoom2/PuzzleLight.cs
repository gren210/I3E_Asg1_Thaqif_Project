using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PuzzleLight : MonoBehaviour
{

    public Material colour;

    string[] order = { "BluePlate", "OrangeMat", "CyanButton", "PurpleButton" };

    public void ButtonPress()
    {

    }





    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
