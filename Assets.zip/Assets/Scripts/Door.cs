using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    bool opened = false;

    public bool locked = true;

    public GameObject doorbox;

    public void OpenDoor()
    {
        if (!locked)
        {
            Vector3 currentRotation = doorbox.transform.eulerAngles;
            currentRotation.y += 90f;
            doorbox.transform.eulerAngles = currentRotation;
            opened = true;
        }
    }

    public void CloseDoor()
    {
        Vector3 currentRotation = doorbox.transform.eulerAngles;
        currentRotation.y -= 90f;
        doorbox.transform.eulerAngles = currentRotation;
        opened = false;
    }

    public void SetLock(bool lockStatus)
    {
        locked = lockStatus;
    }



    private void OnTriggerEnter(Collider other)
    {

        if (other.gameObject.tag == "Player" && !opened)
        {
            other.gameObject.GetComponent<player>().UpdateDoor(this);
        }

    }

    private void OnTriggerExit(Collider collider)
    {
        if (collider.gameObject.tag == "Player")// && opened)
        {
            collider.gameObject.GetComponent<player>().UpdateDoor(null);
            if (opened)
            {
                CloseDoor();
            }
        }
        // Start is called before the first frame update
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
